"""
Generates a synthetic but realistic housing dataset and saves it to data/housing.csv.
Using a synthetic dataset means this project runs fully offline with no downloads.
Swap this out for a real dataset (e.g. Kaggle's House Prices or California Housing)
by replacing the CSV that train_model.py reads from.
"""
import numpy as np
import pandas as pd
import os

np.random.seed(42)
N = 2000

sqft = np.random.normal(1800, 650, N).clip(400, 6000)
bedrooms = np.random.choice([1, 2, 3, 4, 5, 6], N, p=[0.05, 0.15, 0.35, 0.30, 0.10, 0.05])
bathrooms = (bedrooms * 0.75 + np.random.normal(0, 0.5, N)).clip(1, 6).round(1)
age = np.random.exponential(20, N).clip(0, 100)
garage_spaces = np.random.choice([0, 1, 2, 3], N, p=[0.1, 0.3, 0.45, 0.15])
lot_size = np.random.normal(8000, 3000, N).clip(1000, 30000)
location_score = np.random.uniform(1, 10, N)  # 1=rural/low-demand, 10=prime neighborhood
distance_to_city_km = np.random.exponential(12, N).clip(0.5, 80)
has_pool = np.random.choice([0, 1], N, p=[0.85, 0.15])
renovated = np.random.choice([0, 1], N, p=[0.7, 0.3])
school_rating = np.random.uniform(1, 10, N)

# Price formula with realistic weights + noise
price = (
    50000
    + sqft * 145
    + bedrooms * 8000
    + bathrooms * 6000
    - age * 900
    + garage_spaces * 7000
    + lot_size * 2.5
    + location_score * 12000
    - distance_to_city_km * 1200
    + has_pool * 18000
    + renovated * 15000
    + school_rating * 5000
    + np.random.normal(0, 25000, N)
)
price = price.clip(50000, None).round(-2)  # floor + round to nearest 100

df = pd.DataFrame({
    "sqft": sqft.round(0).astype(int),
    "bedrooms": bedrooms,
    "bathrooms": bathrooms,
    "age_years": age.round(1),
    "garage_spaces": garage_spaces,
    "lot_size_sqft": lot_size.round(0).astype(int),
    "location_score": location_score.round(2),
    "distance_to_city_km": distance_to_city_km.round(2),
    "has_pool": has_pool,
    "renovated": renovated,
    "school_rating": school_rating.round(2),
    "price": price.astype(int),
})

os.makedirs("data", exist_ok=True)
df.to_csv("data/housing.csv", index=False)
print(f"Generated {len(df)} rows -> data/housing.csv")
print(df.head())
