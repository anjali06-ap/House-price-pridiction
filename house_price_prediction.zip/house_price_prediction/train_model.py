"""
House Price Prediction — training and evaluation pipeline.

Trains a Linear Regression baseline and a Random Forest model, compares them,
and saves the best model plus evaluation plots.

Run:
    python generate_data.py   # creates data/housing.csv (skip if you have your own)
    python train_model.py
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import os

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

os.makedirs("outputs", exist_ok=True)
sns.set_style("whitegrid")

# ---------------------------------------------------------------
# 1. Load data
# ---------------------------------------------------------------
df = pd.read_csv("data/housing.csv")
print("Dataset shape:", df.shape)
print(df.describe().T[["mean", "std", "min", "max"]])

TARGET = "price"
X = df.drop(columns=[TARGET])
y = df[TARGET]

# ---------------------------------------------------------------
# 2. EDA plots
# ---------------------------------------------------------------
fig, axes = plt.subplots(2, 2, figsize=(12, 9))

sns.histplot(df[TARGET], kde=True, ax=axes[0, 0], color="steelblue")
axes[0, 0].set_title("Price Distribution")

sns.scatterplot(data=df, x="sqft", y="price", hue="bedrooms", palette="viridis", ax=axes[0, 1])
axes[0, 1].set_title("Price vs Square Footage")

corr = df.corr(numeric_only=True)[TARGET].drop(TARGET).sort_values()
corr.plot(kind="barh", ax=axes[1, 0], color="teal")
axes[1, 0].set_title("Feature Correlation with Price")

sns.boxplot(data=df, x="bedrooms", y="price", ax=axes[1, 1], color="lightcoral")
axes[1, 1].set_title("Price by Bedroom Count")

plt.tight_layout()
plt.savefig("outputs/eda_overview.png", dpi=150)
plt.close()
print("Saved outputs/eda_overview.png")

# ---------------------------------------------------------------
# 3. Train/test split + scaling (for linear model)
# ---------------------------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ---------------------------------------------------------------
# 4. Train models
# ---------------------------------------------------------------
models = {
    "Linear Regression": (LinearRegression(), X_train_scaled, X_test_scaled),
    "Random Forest": (RandomForestRegressor(n_estimators=300, max_depth=12, random_state=42, n_jobs=-1), X_train, X_test),
}

results = []
fitted = {}

for name, (model, xtr, xte) in models.items():
    model.fit(xtr, y_train)
    preds = model.predict(xte)

    mae = mean_absolute_error(y_test, preds)
    rmse = np.sqrt(mean_squared_error(y_test, preds))
    r2 = r2_score(y_test, preds)

    cv_scores = cross_val_score(model, xtr, y_train, cv=5, scoring="r2")

    results.append({
        "model": name,
        "MAE": round(mae, 2),
        "RMSE": round(rmse, 2),
        "R2": round(r2, 4),
        "CV_R2_mean": round(cv_scores.mean(), 4),
        "CV_R2_std": round(cv_scores.std(), 4),
    })
    fitted[name] = (model, preds)

results_df = pd.DataFrame(results)
print("\n=== Model Comparison ===")
print(results_df.to_string(index=False))
results_df.to_csv("outputs/model_comparison.csv", index=False)

# ---------------------------------------------------------------
# 5. Pick best model (by R2), plot predictions + feature importance
# ---------------------------------------------------------------
best_name = results_df.sort_values("R2", ascending=False).iloc[0]["model"]
best_model, best_preds = fitted[best_name]
print(f"\nBest model: {best_name}")

fig, axes = plt.subplots(1, 2, figsize=(13, 5))

axes[0].scatter(y_test, best_preds, alpha=0.4, color="steelblue")
lims = [y_test.min(), y_test.max()]
axes[0].plot(lims, lims, "r--", lw=2)
axes[0].set_xlabel("Actual Price")
axes[0].set_ylabel("Predicted Price")
axes[0].set_title(f"{best_name}: Predicted vs Actual")

if hasattr(best_model, "feature_importances_"):
    importances = pd.Series(best_model.feature_importances_, index=X.columns).sort_values()
    importances.plot(kind="barh", ax=axes[1], color="darkorange")
    axes[1].set_title("Feature Importance")
else:
    coefs = pd.Series(best_model.coef_, index=X.columns).sort_values()
    coefs.plot(kind="barh", ax=axes[1], color="darkorange")
    axes[1].set_title("Linear Model Coefficients (scaled)")

plt.tight_layout()
plt.savefig("outputs/best_model_results.png", dpi=150)
plt.close()
print("Saved outputs/best_model_results.png")

# ---------------------------------------------------------------
# 6. Save model + scaler for reuse
# ---------------------------------------------------------------
joblib.dump(best_model, "outputs/best_model.joblib")
joblib.dump(scaler, "outputs/scaler.joblib")
joblib.dump(list(X.columns), "outputs/feature_columns.joblib")
print("Saved outputs/best_model.joblib")

# ---------------------------------------------------------------
# 7. Example: predict a new house
# ---------------------------------------------------------------
example = pd.DataFrame([{
    "sqft": 2200, "bedrooms": 4, "bathrooms": 2.5, "age_years": 8,
    "garage_spaces": 2, "lot_size_sqft": 9000, "location_score": 7.5,
    "distance_to_city_km": 6, "has_pool": 1, "renovated": 0, "school_rating": 8.2,
}])

if best_name == "Linear Regression":
    example_input = scaler.transform(example)
else:
    example_input = example

example_pred = best_model.predict(example_input)[0]
print(f"\nExample prediction for a sample house: ${example_pred:,.0f}")
