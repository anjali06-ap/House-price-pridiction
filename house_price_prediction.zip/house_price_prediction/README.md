# 🏠 House Price Prediction

A complete, runnable machine learning pipeline that predicts house prices from property features — built with scikit-learn, pandas, and matplotlib.

## Features

- 📊 Synthetic dataset generator (runs fully offline, no downloads needed)
- 🔍 Exploratory data analysis with visualizations
- 🤖 Trains and compares **Linear Regression** and **Random Forest** models
- ✅ 5-fold cross-validation
- 💾 Saves the best-performing model for reuse
- 📈 Prediction vs. actual plots + feature importance chart

## Project structure

```
house_price_prediction/
├── generate_data.py      # creates the synthetic dataset
├── train_model.py        # EDA, training, evaluation, saves best model
├── requirements.txt
├── data/
│   └── housing.csv       # generated dataset
├── outputs/               # generated after running train_model.py
│   ├── eda_overview.png
│   ├── best_model_results.png
│   ├── model_comparison.csv
│   ├── best_model.joblib
│   ├── scaler.joblib
│   └── feature_columns.joblib
└── README.md
```

## Getting started

```bash
git clone https://github.com/<your-username>/house-price-prediction.git
cd house-price-prediction
pip install -r requirements.txt

python generate_data.py   # creates data/housing.csv
python train_model.py     # trains models, saves plots + best model
```

## Dataset

The included dataset is synthetically generated (2,000 rows) so the project works out of the box with no external downloads. Features:

`sqft`, `bedrooms`, `bathrooms`, `age_years`, `garage_spaces`, `lot_size_sqft`, `location_score`, `distance_to_city_km`, `has_pool`, `renovated`, `school_rating`

To use real data instead, replace `data/housing.csv` with your own CSV — just keep a `price` column as the target and matching feature columns (or edit `train_model.py`'s feature list).

## Results

| Model | MAE | RMSE | R² | CV R² (mean) |
|---|---|---|---|---|
| Linear Regression | ~$21.3k | ~$26.9k | 0.937 | 0.943 |
| Random Forest | ~$26.8k | ~$33.8k | 0.900 | 0.900 |

*(Your exact numbers may vary slightly by random seed / environment.)*

## Using the saved model

```python
import joblib
import pandas as pd

model = joblib.load("outputs/best_model.joblib")
scaler = joblib.load("outputs/scaler.joblib")
columns = joblib.load("outputs/feature_columns.joblib")

new_house = pd.DataFrame([{
    "sqft": 2200, "bedrooms": 4, "bathrooms": 2.5, "age_years": 8,
    "garage_spaces": 2, "lot_size_sqft": 9000, "location_score": 7.5,
    "distance_to_city_km": 6, "has_pool": 1, "renovated": 0, "school_rating": 8.2,
}])[columns]

# Linear Regression needs scaled input; Random Forest does not
prediction = model.predict(scaler.transform(new_house))
print(f"Predicted price: ${prediction[0]:,.0f}")
```

## Next steps / ideas for contributors

- Swap in a real dataset (e.g. Kaggle's "House Prices - Advanced Regression Techniques")
- Add gradient boosting models (XGBoost / LightGBM) for comparison
- Hyperparameter tuning (GridSearchCV / Optuna)
- Log-transform price to handle skew
- Wrap the model in a small Streamlit or Flask app for interactive predictions

## License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.
